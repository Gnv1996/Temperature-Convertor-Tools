module com.example.myjavaapp {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.myjavaapp to javafx.fxml;
    exports com.example.myjavaapp;
}